/**
 */
package graphviz.impl;

import graphviz.DummyClassForAcceleoWillBeDeleted;
import graphviz.GraphvizPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dummy Class For Acceleo Will Be Deleted</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DummyClassForAcceleoWillBeDeletedImpl extends MinimalEObjectImpl.Container implements DummyClassForAcceleoWillBeDeleted {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DummyClassForAcceleoWillBeDeletedImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return GraphvizPackage.Literals.DUMMY_CLASS_FOR_ACCELEO_WILL_BE_DELETED;
	}

} //DummyClassForAcceleoWillBeDeletedImpl
