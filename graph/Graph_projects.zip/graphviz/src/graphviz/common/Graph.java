/**
 */
package graphviz.common;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Graph</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * This class serves as a base class for all more specific graph
 * classes. It provides one containment for a graph's nodes and another
 * containment for a graph's edges.
 * <!-- end-model-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link graphviz.common.Graph#getNodes <em>Nodes</em>}</li>
 *   <li>{@link graphviz.common.Graph#getEdges <em>Edges</em>}</li>
 * </ul>
 *
 * @see graphviz.common.CommonPackage#getGraph()
 * @model
 * @generated
 */
public interface Graph extends EObject {
	/**
	 * Returns the value of the '<em><b>Nodes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nodes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nodes</em>' containment reference list.
	 * @see graphviz.common.CommonPackage#getGraph_Nodes()
	 * @model type="graphviz.common.Node" containment="true"
	 * @generated
	 */
	EList getNodes();

	/**
	 * Returns the value of the '<em><b>Edges</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Edges</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Edges</em>' containment reference list.
	 * @see graphviz.common.CommonPackage#getGraph_Edges()
	 * @model type="graphviz.common.Edge" containment="true"
	 * @generated
	 */
	EList getEdges();

} // Graph
