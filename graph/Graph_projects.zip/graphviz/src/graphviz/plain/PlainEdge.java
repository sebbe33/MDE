/**
 */
package graphviz.plain;

import graphviz.common.Edge;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Edge</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link graphviz.plain.PlainEdge#getSplinePoints <em>Spline Points</em>}</li>
 * </ul>
 *
 * @see graphviz.plain.PlainPackage#getPlainEdge()
 * @model
 * @generated
 */
public interface PlainEdge extends Edge {
	/**
	 * Returns the value of the '<em><b>Spline Points</b></em>' containment reference list.
	 * The list contents are of type {@link graphviz.util.Point}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Spline Points</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Spline Points</em>' containment reference list.
	 * @see graphviz.plain.PlainPackage#getPlainEdge_SplinePoints()
	 * @model type="graphviz.util.Point" containment="true"
	 * @generated
	 */
	EList getSplinePoints();

} // PlainEdge
