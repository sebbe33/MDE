/**
 */
package graphviz.dot;

import graphviz.common.Edge;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Edge</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link graphviz.dot.DotEdge#getSettings <em>Settings</em>}</li>
 * </ul>
 *
 * @see graphviz.dot.DotPackage#getDotEdge()
 * @model
 * @generated
 */
public interface DotEdge extends Edge {
	/**
	 * Returns the value of the '<em><b>Settings</b></em>' containment reference list.
	 * The list contents are of type {@link graphviz.dot.Setting}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Settings</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Settings</em>' containment reference list.
	 * @see graphviz.dot.DotPackage#getDotEdge_Settings()
	 * @model type="graphviz.dot.Setting" containment="true"
	 * @generated
	 */
	EList getSettings();

} // DotEdge
