/**
 */
package graphviz;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dummy Class For Acceleo Will Be Deleted</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see graphviz.GraphvizPackage#getDummyClassForAcceleoWillBeDeleted()
 * @model
 * @generated
 */
public interface DummyClassForAcceleoWillBeDeleted extends EObject {
} // DummyClassForAcceleoWillBeDeleted
