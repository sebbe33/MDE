/**
 */
package core.expressions.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Comparing Operator</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * <!-- begin-model-doc -->
 * Defines the operators for comparing expressions. The operators LESS, LESS_OR_EQUAL, EQUAL,
 * GREATER_OR_EQUAL, GREATER, and UNEQUAL have their usual semantics.
 * The operator REGULAR_EXPRESSION enables to compare a String contained in the
 * left hand side of a ComparisonExpression with a regular expression contained in the 
 * right hand side of the ComparisonExpression.
 * <!-- end-model-doc -->
 * @see core.expressions.common.CommonPackage#getComparingOperator()
 * @model
 * @generated
 */
public final class ComparingOperator extends AbstractEnumerator {
	/**
	 * The '<em><b>LESS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>LESS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LESS_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int LESS = 0;

	/**
	 * The '<em><b>LESS OR EQUAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>LESS OR EQUAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LESS_OR_EQUAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int LESS_OR_EQUAL = 1;

	/**
	 * The '<em><b>EQUAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>EQUAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EQUAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int EQUAL = 2;

	/**
	 * The '<em><b>GREATER OR EQUAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>GREATER OR EQUAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #GREATER_OR_EQUAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int GREATER_OR_EQUAL = 3;

	/**
	 * The '<em><b>GREATER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>GREATER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #GREATER_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int GREATER = 4;

	/**
	 * The '<em><b>UNEQUAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNEQUAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNEQUAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int UNEQUAL = 5;

	/**
	 * The '<em><b>REGULAR EXPRESSION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * <!-- begin-model-doc -->
	 * For comparison of a String with a regular expression.
	 * <!-- end-model-doc -->
	 * @see #REGULAR_EXPRESSION_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int REGULAR_EXPRESSION = 6;

	/**
	 * The '<em><b>LESS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LESS
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator LESS_LITERAL = new ComparingOperator(LESS, "LESS", "LESS");

	/**
	 * The '<em><b>LESS OR EQUAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LESS_OR_EQUAL
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator LESS_OR_EQUAL_LITERAL = new ComparingOperator(LESS_OR_EQUAL, "LESS_OR_EQUAL", "LESS_OR_EQUAL");

	/**
	 * The '<em><b>EQUAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EQUAL
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator EQUAL_LITERAL = new ComparingOperator(EQUAL, "EQUAL", "EQUAL");

	/**
	 * The '<em><b>GREATER OR EQUAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GREATER_OR_EQUAL
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator GREATER_OR_EQUAL_LITERAL = new ComparingOperator(GREATER_OR_EQUAL, "GREATER_OR_EQUAL", "GREATER_OR_EQUAL");

	/**
	 * The '<em><b>GREATER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #GREATER
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator GREATER_LITERAL = new ComparingOperator(GREATER, "GREATER", "GREATER");

	/**
	 * The '<em><b>UNEQUAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNEQUAL
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator UNEQUAL_LITERAL = new ComparingOperator(UNEQUAL, "UNEQUAL", "UNEQUAL");

	/**
	 * The '<em><b>REGULAR EXPRESSION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REGULAR_EXPRESSION
	 * @generated
	 * @ordered
	 */
	public static final ComparingOperator REGULAR_EXPRESSION_LITERAL = new ComparingOperator(REGULAR_EXPRESSION, "REGULAR_EXPRESSION", "REGULAR_EXPRESSION");

	/**
	 * An array of all the '<em><b>Comparing Operator</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ComparingOperator[] VALUES_ARRAY =
		new ComparingOperator[] {
			LESS_LITERAL,
			LESS_OR_EQUAL_LITERAL,
			EQUAL_LITERAL,
			GREATER_OR_EQUAL_LITERAL,
			GREATER_LITERAL,
			UNEQUAL_LITERAL,
			REGULAR_EXPRESSION_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Comparing Operator</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Comparing Operator</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ComparingOperator get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ComparingOperator result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Comparing Operator</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ComparingOperator getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ComparingOperator result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Comparing Operator</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ComparingOperator get(int value) {
		switch (value) {
			case LESS: return LESS_LITERAL;
			case LESS_OR_EQUAL: return LESS_OR_EQUAL_LITERAL;
			case EQUAL: return EQUAL_LITERAL;
			case GREATER_OR_EQUAL: return GREATER_OR_EQUAL_LITERAL;
			case GREATER: return GREATER_LITERAL;
			case UNEQUAL: return UNEQUAL_LITERAL;
			case REGULAR_EXPRESSION: return REGULAR_EXPRESSION_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ComparingOperator(int value, String name, String literal) {
		super(value, name, literal);
	}

} //ComparingOperator
